local SLIDE_DURATION = 0.75
local SLIDE_SPEED_MULTIPLIER = 1.25
local VELOCITY_THRESHOLD = 400

local function camera_base(self)
    local camera = alive(self._unit) and self._unit:camera()
    local camera_unit = camera and camera:camera_unit()

    return alive(camera_unit) and camera_unit:base() or nil
end

local function has_slide_camera_limit(base)
    local limits = base and base._limits

    return limits and limits.spin and limits.spin.offset == 100 and not limits.pitch
end

function PlayerStandard:_start_slide()
	-- Advanced Movement (and Restoration's extension of it) owns these
	-- fields when installed. Keep this mod's bot colors without a second
	-- sliding lifecycle clearing Advanced Movement's direction/speed.
	if AdvMov and AdvMov.settings then
		return
	end
    if self._slide_expire or not self._last_velocity_xy then
        return
    end

    local slide_dir = mvector3.copy(self._last_velocity_xy)
    local speed = mvector3.normalize(slide_dir) * SLIDE_SPEED_MULTIPLIER

    if speed <= VELOCITY_THRESHOLD then
        return
    end

    self._slide_speed = speed
    self._slide_expire = SLIDE_DURATION
    self._slide_dir = slide_dir

    local base = camera_base(self)

    if base then
        self._slide_previous_camera_limits = base._limits and deep_clone(base._limits) or false
        base:set_limits(100, nil)
    end
end

function PlayerStandard:_stop_slide()
    if not self._slide_expire and self._slide_previous_camera_limits == nil then
        return
    end

    self._slide_expire = nil
    self._slide_speed = nil
    self._slide_dir = nil

    local base = camera_base(self)

    if base and has_slide_camera_limit(base) then
        if self._slide_previous_camera_limits then
            base._limits = self._slide_previous_camera_limits
        else
            base:remove_limits()
        end
    end

    self._slide_previous_camera_limits = nil
end

Hooks:PreHook(PlayerStandard, "enter", "SlidingAndColorfulName_Enter", function(self)
    self:_stop_slide()
end)

Hooks:PreHook(PlayerStandard, "exit", "SlidingAndColorfulName_Exit", function(self)
    self:_stop_slide()
end)

Hooks:PreHook(PlayerStandard, "_start_action_ducking", "SlidingAndColorfulName_StartDucking", function(self)
    if self._running and self._move_dir and not self._state_data.in_air and not self:_on_zipline() then
        self:_start_slide()
    end
end)

Hooks:PreHook(PlayerStandard, "_end_action_ducking", "SlidingAndColorfulName_EndDucking", function(self)
    self:_stop_slide()
end)

Hooks:PreHook(PlayerStandard, "_update_foley", "SlidingAndColorfulName_UpdateFoley", function(self)
    if self._gnd_ray and self._state_data.in_air and not self._state_data.on_ladder and self._state_data.ducking then
        self:_start_slide()
    end
end)

Hooks:PostHook(PlayerStandard, "_determine_move_direction", "SlidingAndColorfulName_MoveDirection", function(self)
    if self._slide_expire and self._slide_dir then
        self._move_dir = self._slide_dir
    end
end)

Hooks:PostHook(PlayerStandard, "_get_max_walk_speed", "SlidingAndColorfulName_MaxWalkSpeed", function(self)
    if self._slide_speed then
        return self._slide_speed
    end
end)

Hooks:PostHook(PlayerStandard, "update", "SlidingAndColorfulName_Update", function(self, t, dt)
    if self._slide_expire then
        self._slide_expire = self._slide_expire - dt

        if self._slide_expire <= 0 then
            self:_stop_slide()
        end
    end
end)
